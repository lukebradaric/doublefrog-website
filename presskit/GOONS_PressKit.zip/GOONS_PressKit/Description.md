# GOONS! — Description

Use whichever length fits. Feel free to quote, trim or rephrase.

## Short (one line)

GOONS! is an auto-battler roguelike: fill a board with silly little Goons, then watch them fight on their own.

## Medium (a paragraph)

GOONS! is an auto-battler roguelike from the two-person studio DoubleFrog. Buy Goons and Items,
place them on a board that grows tile by tile, combine copies into Silver and Golden forms, then sit back as
your board fights the enemy's on its own. Every system is simple; the depth comes from how Goons feed off
each other. Travel sector by sector through fights, shops and special rooms, beat each sector's boss, and
build the strangest board you can. Play solo, or take a PvP run where every boss is another real
player's board.

## Long

GOONS! is an auto-battler roguelike about building a board of odd little creatures and watching
them go to work.

Each run starts with a small board and a handful of gold. Shop for Goons and Items, reroll for better
offers, and place them on a board that grows a tile at a time after every fight. Three copies of a Goon
combine into a Silver, two Silvers into a Golden. Feed Items to your Goons to change them for good.

When the fight starts, your hands are off. Goons poison, crit, heal, shield, freeze and pay out gold on
their own, and both boards share a single health bar each: the first to reach zero loses.

Between fights, chart a course across a map of battles, shops and special rooms, sector by sector, each
ending in a boss that pays out a Trinket, a run-wide buff to build around. Do things during runs to unlock
new Goons for the next one. On a PvP run, every boss is a board built by another real player.

GOONS! is made by DoubleFrog — Luke Bradaric and Francesca Mancillas.
