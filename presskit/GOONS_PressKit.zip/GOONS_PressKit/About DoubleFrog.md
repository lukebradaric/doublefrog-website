# About DoubleFrog

DoubleFrog is a two-person indie studio: **Luke Bradaric** and **Francesca Mancillas**. GOONS! is our [TODO: first?] game.

We're based in the USA. We met while working at Blizzard Entertainment, and now we make silly games together
as DoubleFrog!

- Steam: https://store.steampowered.com/app/1598400
- Discord: https://discord.com/invite/9V5pJeUgAH
- Website: https://doublefrog.games
- Contact: playgoonsgame@gmail.com
- Socials: @playgoonsgame on Instagram (https://www.instagram.com/playgoonsgame), TikTok (https://www.tiktok.com/@playgoonsgame) and YouTube (https://www.youtube.com/@playgoonsgame)
