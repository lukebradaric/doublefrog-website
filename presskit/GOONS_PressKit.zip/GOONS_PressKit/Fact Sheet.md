# GOONS! — Fact Sheet

| | |
| --- | --- |
| **Title** | GOONS! |
| **Developer** | DoubleFrog |
| **Publisher** | DoubleFrog (self-published) |
| **Team** | Luke Bradaric and Francesca Mancillas (two developers) |
| **Based in** | USA |
| **Release date** | TBA |
| **Platforms** | PC (Windows) and Mac, on Steam |
| **Price** | TBA |
| **Genre** | Auto-battler roguelike, solo and async PvP |
| **Languages** | English |
| **Steam** | https://store.steampowered.com/app/1598400 |
| **Discord** | https://discord.com/invite/9V5pJeUgAH |
| **Website** | https://doublefrog.games |
| **Press contact** | playgoonsgame@gmail.com |
| **Socials** | @playgoonsgame on Instagram (https://www.instagram.com/playgoonsgame), TikTok (https://www.tiktok.com/@playgoonsgame) and YouTube (https://www.youtube.com/@playgoonsgame) |

## In a sentence

Fill a board with silly little Goons, then watch them fight an enemy board all on their own.

## Key features

- **Build a board that grows.** Win tiles from every fight and place them to shape where your Goons stand.
- **Over 80 Goons to discover**, each with its own trick: poison, crits, shields, healing, gold and more.
- **Combine copies** to grow a Goon from Bronze to Silver to Golden.
- **Feed Goons Items** to change them for good.
- **Hands-off fights.** Once the battle starts, your board does the work. Both sides share one health bar.
- **Chart a course** through sectors of fights, shops and strange special rooms, each ending in a boss.
- **Collect Trinkets**, run-wide buffs that bend your whole board around them.
- **Unlock new Goons** by doing things in runs: winning, feeding, poisoning a lot...
- **Async PvP**: on a PvP run, every boss is another real player's board.
