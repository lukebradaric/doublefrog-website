# GOONS! — Content Creator Guidelines

[DRAFT: DoubleFrog to confirm before publishing.]

**Yes, you can make videos and streams of GOONS!**

- You may stream, record and upload GOONS! gameplay on any platform (YouTube, Twitch, TikTok, etc.).
- You may **monetize** those videos and streams.
- You may use everything in this press kit (logos, art, screenshots, trailer, characters) in your
  thumbnails, overlays, videos and articles.
- The game's music and sound effects are made for GOONS! and are safe to use in your videos.
  [TODO: confirm the composer agrees; if not, remove this line.]

We only ask that you:

- Don't present the art as your own, sell it, or use it to make a different game.
- Don't edit the GOONS! logo itself (resizing and placing it on backgrounds is fine).
- Link the Steam page if you can: https://store.steampowered.com/app/1598400

## Naming things

- The game is **GOONS!** (capitals and exclamation mark) in titles; "Goons" in running text is fine.
- The creatures are **Goons**; things that don't fight are **Items**.
- Tiers are **Bronze, Silver, Golden**.

## Want a key or have a question?

Email playgoonsgame@gmail.com or find us on Discord: https://discord.com/invite/9V5pJeUgAH
